아래 목록 처리되어 있음 
requirements 생성
base.html
url 분할
django-extention
crud 프로젝트 생성
articles 앱 생성
ModelForm 적용
DB migrations 적용
언어/시간 한국으로 맞춤

