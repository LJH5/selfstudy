준비된 목록
- requirements 및 settings 등록
- my_api 프로젝트
- articles 앱 생성 및 등록, url 분리