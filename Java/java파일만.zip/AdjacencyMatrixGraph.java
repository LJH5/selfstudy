public class AdjacencyMatrixGraph {
	
	private static final int EDGE_EXIST = 1;
	private static final int EDGE_NONE = 0;
	
	private int _numberOfVertices;
	private int _numberOfEdges;
	private int[][] _adjacency;
	
	public AdjacencyMatrixGraph (int givenNumberOfVertices) {
		this.setNumberOfVertices(givenNumberOfVertices);
		this.setNUmberOfEdges(0);
		this.setAdjacency(new int[givenNumberOfVertices][givenNumberOfVertices]);
		for (int tailVertex = 0; tailVertex < this.numberOfVertices(); tailVertex++) {
			for (int headVertex = 0; headVertex < this.numberOfVertices(); headVertex++) {
				this.adjacency()[tailVertex][headVertex] = AdjacencyMatrixGraph.EDGE_NONE;
			}
		}
	}
	public int numberOfVertices() { //getter
		//get num of vertex
		return this._numberOfVertices;
	}
	public int numberOfEdges() { //getter
		//get num of dege
		return this._numberOfEdges;
	}
	private void setNumberOfVertices(int newNumberOfVertices) { //Setter
		this._numberOfVertices = newNumberOfVertices;
	}
	private void setNUmberOfEdges(int newNumberOfEdges) { //Setter
		this._numberOfEdges = newNumberOfEdges;
	}
	private void setAdjacency(int[][] newAdjacecy) { //setter
		this._adjacency = newAdjacecy;
	}
	private int[][] adjacency() { //getter
		return this._adjacency;
	}
	public boolean vertexDoesExist(int aVertex) {
		//check vertex exist
		return (aVertex >= 0 && aVertex < this.numberOfVertices());
	}
	public boolean edgeDoesExist(Edge anEdge) {
		//check edge exist
		if (anEdge != null) {
			int tailVertex = anEdge.tailVertex();
			int headVertex = anEdge.headVertex();
			if (this.vertexDoesExist(tailVertex) && this.vertexDoesExist(headVertex)) {
				return (this.adjacencyOfEdgeDoesExist(tailVertex, headVertex));
			}
		}
		return false;
	}
	private boolean adjacencyOfEdgeDoesExist(int tailVertex, int headVertex) {
		//check adjacency exist
		return (this.adjacency()[tailVertex][headVertex] != AdjacencyMatrixGraph.EDGE_NONE);
	}
	public boolean addEdge(Edge anEdge) {
		if (anEdge != null) {
			int tailVertex = anEdge.tailVertex();
			int headVertex = anEdge.headVertex();
			if (this.vertexDoesExist(tailVertex) && this.vertexDoesExist(headVertex)) {
				this.adjacency()[anEdge.tailVertex()][anEdge.headVertex()] = AdjacencyMatrixGraph.EDGE_EXIST;
				this.adjacency()[anEdge.headVertex()][anEdge.tailVertex()] = AdjacencyMatrixGraph.EDGE_EXIST;
				this.setNUmberOfEdges(this.numberOfEdges()+1);
				return true;
			}
		}
		return true;
	}
	
}