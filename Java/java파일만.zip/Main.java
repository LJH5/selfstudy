
public class Main {
	public static void main(String[] args) {
		AppController appController = new AppController();
		appController.run();
	}

}