<template>
  <div>
    <img alt="Vue logo" src="../assets/logo.png">
    <h1>첫 번째 페이지 입니다</h1>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>