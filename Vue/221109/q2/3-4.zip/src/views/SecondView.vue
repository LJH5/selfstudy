<template>
  <h1>두 번째 페이지 입니다</h1>
</template>

<script>
export default {

}
</script>

<style>

</style>